﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectCode
{
    public partial class PersonalDetails : System.Web.UI.Page
    {
       public  static string str;

        string strConn = @"Server=IN-5CG016FYPP\SQLEXPRESS;DataBase=Project;Integrated Security=True";
        SqlConnection objConn;
        SqlDataReader dataReader;
        string strcmd;
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            
                objConn = new SqlConnection(strConn);
                objConn.Open();

                cmd = new SqlCommand();
                cmd.Connection = objConn;
                cmd.CommandType = CommandType.Text;

                int verify = 0;
                cmd.CommandText = "select  count(*)from PersonalDetails where UserName= '" + txtUserName.Text + "'";

                verify = Convert.ToInt32(cmd.ExecuteScalar());

                if (verify > 0)
                {
                    Label1.Visible = true;
                    Label1.Text = txtUserName.Text + " already exist try with another name";
                }
                else
                {
                    strcmd = "insert into UserLogin(UserName,Password) Values('" + txtUserName.Text + "','" + txtPassword.Text + "')";
                    objConn = new SqlConnection(strConn);
                    cmd = new SqlCommand(strcmd, objConn);
                    objConn.Open();
                    dataReader = cmd.ExecuteReader();
                    objConn.Close();

                    str = txtUserName.Text;



                    string s = txtFirstName.Text + " " + txtLastName.Text;
                    string add = Request.Form["txtAddress"];
                    strcmd = "insert into PersonalDetails(Name,Age,Mobile,MailID,Gender,Address,UserName,Password,ConformPassword) Values('" + s + "', '" + txtAge.Text + "', '" + txtContact.Text + "','" + txtEmail.Text + "', '" + ddlGender.SelectedValue + "','" + add + "','" + txtUserName.Text + "','" + txtPassword.Text + "','" + txtConfirmPassword.Text + "')";
                    objConn = new SqlConnection(strConn);
                    cmd = new SqlCommand(strcmd, objConn);
                    objConn.Open();
                    dataReader = cmd.ExecuteReader();
                    objConn.Close();

                    Response.Redirect("~\\CourseDetails.aspx");
                }
                objConn.Close();
        }

        protected void txtUserName_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
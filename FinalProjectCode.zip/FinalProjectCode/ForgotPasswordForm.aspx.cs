﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectCode
{
    public partial class ForgotPasswordForm : System.Web.UI.Page
    {
        string strConn = @"Server=IN-5CG016FYPP\SQLEXPRESS;DataBase=Project;Integrated Security=True";
        SqlConnection objConn;
        SqlCommand objCmd;
        SqlDataReader dataReader;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btngetpass_Click(object sender, EventArgs e)
        {
          
            objConn = new SqlConnection();

            objConn.ConnectionString = strConn;
            objConn.Open();

            objCmd = new SqlCommand();
            objCmd.Connection = objConn;
            objCmd.CommandType = CommandType.Text;

            int verify = 0;
            objCmd.CommandText = "select  count(*)from UserLogin where UserName= '" + txtemail.Text + "'";

            verify = Convert.ToInt32(objCmd.ExecuteScalar());
           
            if (verify > 0)
            {
                objCmd.CommandText = "update UserLogin set Password='" + txtpassword.Text + "' where UserName= '" + txtemail.Text + "'";
                objConn = new SqlConnection(strConn);


                dataReader = objCmd.ExecuteReader();

                lblpass.Visible = true;
                lblpass.Text = "password changed";
            }
            else
            {
                lblpass.Visible = true;
                lblpass.Text = "invalid username";
            }
            objConn.Close();

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectCode
{
    public partial class GenerateReport : System.Web.UI.Page
    {
        string strConn = @"Server=IN-5CG016FYPP\SQLEXPRESS;DataBase=Project;Integrated Security=True";
        SqlConnection objConn;
        SqlCommand objCmd;
        SqlDataAdapter objAdapter;
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
      
        protected void btnCourseShow_Click(object sender, EventArgs e)
        {
            Label1.Visible = true;
            Label1.Text = "CourseWiseReport "; 
             
             objConn = new SqlConnection();
             objConn.ConnectionString = strConn;

            objCmd = new SqlCommand();
            objCmd.Connection = objConn;
            objCmd.CommandType = CommandType.Text;
            objCmd.CommandText = "select UserName,CourseType,Status from  CourseDetails where CourseType = '" + DropDownList1.SelectedValue + "'";

            objAdapter = new SqlDataAdapter();
            ds = new DataSet();
            objAdapter.SelectCommand = objCmd;
            objAdapter.Fill(ds, "CourseReport");

            dgvcourse.DataSource = ds;
            dgvcourse.DataMember = "CourseReport";
            dgvcourse.DataBind();
        }

        protected void btnStatusShow_Click(object sender, EventArgs e)
        {
            Label2.Visible = true;
            Label2.Text = "StatusWiseReport";
            
            objConn = new SqlConnection();
            objConn.ConnectionString = strConn;

            objCmd = new SqlCommand();
            objCmd.Connection = objConn;
            objCmd.CommandType = CommandType.Text;
            objCmd.CommandText = "select UserName,CourseType,Status from  CourseDetails where Status = '" + DropDownList2.SelectedValue + "'";

            objAdapter = new SqlDataAdapter();
            ds = new DataSet();
            objAdapter.SelectCommand = objCmd;
            objAdapter.Fill(ds, "StatusReport");

            dgvreport.DataSource = ds;
            dgvreport.DataMember = "StatusReport";
            dgvreport.DataBind();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("~\\AdminWork.aspx");
        }
       
    }
}
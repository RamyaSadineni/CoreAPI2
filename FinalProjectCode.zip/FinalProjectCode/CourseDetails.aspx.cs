﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectCode
{
    public partial class CourseDetails : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Sucessfull.Visible = false;
            HyperLink1.Visible = false;
            HyperLink2.Visible = false;
           
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string strConn = @"Server=IN-5CG016FYPP\SQLEXPRESS;DataBase=Project;Integrated Security=True";
            SqlConnection objConn;
            SqlDataReader dataReader;



            string chklist = string.Empty;
            for (int i = 0; i < CheckBoxList1.Items.Count; i++)
            {
                if (CheckBoxList1.Items[i].Selected)
                {
                    if (chklist == "")
                    {
                        chklist = CheckBoxList1.Items[i].Text;
                    }
                    else
                    {
                        chklist += "," + CheckBoxList1.Items[i].Text;
                    }

                }
            }

            string user = PersonalDetails.str;
            string strcmd = "insert into CourseDetails(CourseType,SelectedCourse,PreviousSkills,Status,UserName) Values('" + ddlTypecourse.SelectedValue + "', '" + ddlselectCourse.SelectedValue + "', '" + chklist + "', '" + "Not Assigned" + "', '" + user + "') ";
            objConn = new SqlConnection(strConn);
            SqlCommand cmd = new SqlCommand(strcmd, objConn);
            objConn.Open();
            dataReader = cmd.ExecuteReader();
            objConn.Close();

            Sucessfull.Visible = true;
            HyperLink1.Visible = true;
            HyperLink2.Visible = true;
            Response.Redirect("~\\UserLogin.aspx");
        }

        protected void ddlTypecourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlselectCourse.Items.Clear();
            switch (ddlTypecourse.SelectedItem.ToString())
            {
                case "Academic":
                    ddlselectCourse.Items.Add("M.C.A");
                    ddlselectCourse.Items.Add("B.Tech");
                    ddlselectCourse.Items.Add("B.Com");
                    ddlselectCourse.Items.Add("M.B.A");
                    ddlselectCourse.Items.Add("B.Sc");
                    break;
                case "Vocational":
                    ddlselectCourse.Items.Add("Java");
                    ddlselectCourse.Items.Add("Python");
                    ddlselectCourse.Items.Add("Oracle");
                    ddlselectCourse.Items.Add("C");
                    break;

            }
        }
    }
}
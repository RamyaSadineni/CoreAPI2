﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectCode
{
    public partial class UserLogin : System.Web.UI.Page
    {
        string strConn =@"Server=IN-5CG016FYPP\SQLEXPRESS;DataBase=Project;Integrated Security=True";
        SqlConnection objConn;
        SqlCommand objCmd;
        public static string Name;
        public static string Name1;
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
            Name = PersonalDetails.str;
            int verify;

            Name1 = TxtUseName.Text;
            objConn = new SqlConnection();

            objConn.ConnectionString = strConn;
            objConn.Open();

            objCmd = new SqlCommand();
            objCmd.Connection = objConn;
            objCmd.CommandType = CommandType.Text;
            // and Password='" + TxtPassword.Text + "'

            objCmd.CommandText = "select  count(*)from UserLogin where UserName= '" + TxtUseName.Text + "'";

            verify = Convert.ToInt32(objCmd.ExecuteScalar());
            int i = 0;
            if (verify > 0)
            {
                objCmd.CommandText = "select  count(*)from UserLogin where UserName= '" + TxtUseName.Text + "'and Password='" + TxtPassword.Text + "'";
                i = Convert.ToInt32(objCmd.ExecuteScalar());
                if (i > 0)
                {
                    Response.Redirect("~\\UserData.aspx");
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "invalid password";
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "invalid user";
            }



        }

        protected void btn_Submit_Click(object sender, EventArgs e)
        {
            Response.Redirect("~\\PersonalDetails.aspx");
        }

        protected void TxtUseName_TextChanged(object sender, EventArgs e)
        {
        }


    }
}
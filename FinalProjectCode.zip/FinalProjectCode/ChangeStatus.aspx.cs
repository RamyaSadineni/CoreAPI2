﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectCode
{
    public partial class ChangeStatus : System.Web.UI.Page
    {
        string strConn = @"Server=IN-5CG016FYPP\SQLEXPRESS;DataBase=Project;Integrated Security=True";
        SqlDataAdapter adapter;
        SqlConnection objConn;
        DataSet ds;
        SqlDataReader dataReader;

        protected void Page_Load(object sender, EventArgs e)
        {
           

            if (!Page.IsPostBack)
            {
                string query = "select UserName from CourseDetails";
              
                objConn = new SqlConnection(strConn);
                objConn.Open();
                SqlCommand cmd = new SqlCommand(query, objConn);
                SqlDataReader reader = cmd.ExecuteReader();
                DropDownList1.Items.Clear();
                while (reader.Read())
                {
                    DropDownList1.Items.Add(reader.GetString(0));
                }
                objConn.Close();

            }


            lblUpdate.Visible = false;
        }
      
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
           

            string update = "Update CourseDetails set Status='" + DropDownList2.SelectedValue + "'where UserName='" + DropDownList1.SelectedValue + "'";
            objConn = new SqlConnection(strConn);
            SqlCommand cmd = new SqlCommand(update, objConn);
            objConn.Open();
            cmd.ExecuteNonQuery();
            objConn.Close();
            
            lblUpdate.Visible = true;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("~\\AdminWork.aspx");
        }
    }
}
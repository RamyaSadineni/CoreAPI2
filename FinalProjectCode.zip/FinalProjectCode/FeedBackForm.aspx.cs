﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectCode
{
    public partial class FeedBackForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Visible = false;
        }

        protected void Btn_submit_Click(object sender, EventArgs e)
        {
            string strConn = @"Server=IN-5CG016FYPP\SQLEXPRESS;DataBase=Project;Integrated Security=True";
            SqlConnection objConn;
            SqlDataReader dataReader;
            string strcmd = "insert into Feedback(Name,MailId,FeedBack) Values('" + TxtName.Text + "', '" + Txtmail.Text + "', '" + txtmsg.Text + "')";
            objConn = new SqlConnection(strConn);
            SqlCommand cmd = new SqlCommand(strcmd, objConn);
            objConn.Open();
            dataReader = cmd.ExecuteReader();
            objConn.Close();

            Label1.Visible = true;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjectCode
{
    public partial class UserData : System.Web.UI.Page
    {
        string strConn = @"Server=IN-5CG016FYPP\SQLEXPRESS;DataBase=Project;Integrated Security=True";
        SqlConnection objConn;
        SqlCommand objCmd;
        SqlDataAdapter objAdapter;
        DataSet ds;
        string user = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       
        protected void Button1_Click(object sender, EventArgs e)
        {
            user = UserLogin.Name1;
           
            Label1.Visible = true;
            Label1.Text =user+ " Details ";

            objConn = new SqlConnection();
            objConn.ConnectionString = strConn;

            objCmd = new SqlCommand();
            objCmd.Connection = objConn;
            objCmd.CommandType = CommandType.Text;
            
            objCmd.CommandText = "select PersonalDetails.Name, PersonalDetails.Age,PersonalDetails.Mobile,PersonalDetails.MailID,PersonalDetails.Gender,PersonalDetails.Address,PersonalDetails.UserName,CourseDetails.CourseType,CourseDetails.SelectedCourse,CourseDetails.PreviousSkills,CourseDetails.Status from PersonalDetails inner join CourseDetails on PersonalDetails.UserName=CourseDetails.UserName where PersonalDetails.UserName='" + user+ "'";

            objAdapter = new SqlDataAdapter();
            ds = new DataSet();
            objAdapter.SelectCommand = objCmd;
            objAdapter.Fill(ds, "CourseReport");

            GridView1.DataSource = ds;
            GridView1.DataMember = "CourseReport";
            GridView1.DataBind();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~\\UserLogin.aspx");
        }
    }
}
